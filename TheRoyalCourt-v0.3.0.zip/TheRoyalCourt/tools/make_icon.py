from PIL import Image, ImageDraw, ImageFilter

N = 1024
img = Image.new("RGBA", (N, N), (0, 0, 0, 0))

# background: rounded square with a vertical royal-purple gradient
bg = Image.new("RGBA", (N, N))
px = bg.load()
top, bot = (84, 26, 70), (36, 10, 40)
for y in range(N):
    t = y / (N - 1)
    c = tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(3)) + (255,)
    for x in range(N):
        px[x, y] = c
mask = Image.new("L", (N, N), 0)
ImageDraw.Draw(mask).rounded_rectangle((24, 24, N - 24, N - 24), radius=190, fill=255)
img.paste(bg, (0, 0), mask)

d = ImageDraw.Draw(img)
GOLD, GOLD_D, GOLD_L = (236, 183, 44), (166, 112, 18), (255, 226, 130)
RED, RED_D = (176, 24, 62), (120, 14, 44)

def poly(pts, fill, outline=None):
    d.polygon(pts, fill=fill)
    if outline:
        d.line(pts + [pts[0]], fill=outline, width=10, joint="curve")

# soft floor shadow
sh = Image.new("RGBA", (N, N), (0, 0, 0, 0))
ImageDraw.Draw(sh).ellipse((220, 835, 804, 925), fill=(0, 0, 0, 120))
img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(18)))
d = ImageDraw.Draw(img)

# tall pointed backrest (gold frame + crimson panel)
back = [(318, 640), (318, 330), (410, 215), (512, 140), (614, 215), (706, 330), (706, 640)]
poly(back, GOLD, GOLD_D)
panel = [(372, 625), (372, 345), (512, 205), (652, 345), (652, 625)]
poly(panel, RED, RED_D)
# highlight stripe on frame
d.line([(334, 630), (334, 336), (418, 232), (512, 160)], fill=GOLD_L, width=12, joint="curve")

# finials: top and two side posts
for (cx, cy, r) in [(512, 112, 36), (300, 262, 30), (724, 262, 30)]:
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=GOLD, outline=GOLD_D, width=8)
    d.ellipse((cx - r // 2, cy - r // 2 - 4, cx, cy - 2), fill=GOLD_L)
for x0 in (276, 700):
    d.rounded_rectangle((x0, 288, x0 + 48, 700), radius=14, fill=GOLD, outline=GOLD_D, width=8)

# armrests
for x0, x1 in ((236, 372), (652, 788)):
    d.rounded_rectangle((x0, 540, x1, 606), radius=26, fill=GOLD, outline=GOLD_D, width=8)

# seat cushion + seat block
d.rounded_rectangle((330, 590, 694, 668), radius=24, fill=RED, outline=RED_D, width=8)
d.rounded_rectangle((300, 660, 724, 750), radius=18, fill=GOLD, outline=GOLD_D, width=8)
d.line([(320, 676), (704, 676)], fill=GOLD_L, width=10)

# legs / feet
for x0 in (316, 656):
    d.rounded_rectangle((x0, 744, x0 + 56, 850), radius=12, fill=GOLD_D, outline=GOLD_D)
    d.rounded_rectangle((x0 - 18, 830, x0 + 74, 884), radius=16, fill=GOLD, outline=GOLD_D, width=8)

img.save("throne_1024.png")
sizes = [16, 24, 32, 48, 64, 128, 256]
imgs = [img.resize((s, s), Image.LANCZOS) for s in sizes]
imgs[-1].save("royalcourt.ico", format="ICO", sizes=[(s, s) for s in sizes], append_images=imgs[:-1])

# preview sheet: 256 plus enlarged small sizes on a light and dark strip
sheet = Image.new("RGBA", (256 + 3 * 140 + 40, 300), (235, 235, 235, 255))
sheet.alpha_composite(imgs[-1], (10, 20))
x = 286
for s in (48, 32, 16):
    big = img.resize((s, s), Image.LANCZOS).resize((120, 120), Image.NEAREST)
    sheet.alpha_composite(big, (x, 20)); x += 140
sheet.save("preview.png")
print("ok")
