# The Royal Court | CK3 Mod Manager  v0.3.0

Double-click `TheRoyalCourt.exe` (Windows 7 or newer, 64-bit). It is a normal desktop program: no installer, no browser, no internet access.

## What it does
- Finds your Crusader Kings III folder and lists installed mods.
- Playsets: New, Duplicate, Rename, Delete (saved in %APPDATA%\TheRoyalCourt\playsets.json).
- Export a playset to a shareable file and Import one someone sends you (missing mods are shown by name).
- Tick mods on/off, filter by name, drag rows (or Move up/down) to set load order.
- "Apply playset" writes the enabled mods to dlc_load.json in your CK3 folder. A timestamped backup (dlc_load.json.rc-backup-...) is saved first.

## About the antivirus warning
The EXE is not code-signed (certificates cost money), and brand-new unsigned programs are often flagged by heuristic scanners even when clean. You can check it yourself:
1. Compare the file's SHA-256 with SHA256SUMS.txt (PowerShell: `Get-FileHash .\TheRoyalCourt.exe`).
2. Upload it to https://www.virustotal.com and see how many engines flag it; one or two heuristic hits on an unsigned new file is a typical false positive.
3. The complete source is in the `src` folder; nothing is hidden. The program only reads your CK3 `mod` folder and writes `dlc_load.json` and its own playsets.json.
4. If Microsoft Defender flags it, you can report it as a false positive at https://www.microsoft.com/wdsi/filesubmission

## Rebuilding
On Linux: install g++-mingw-w64-x86-64 and binutils-mingw-w64-x86-64, then run `src/build.sh`. Tests for the core logic are in `src/tests`.

Every change is logged in CHANGELOG.md.
