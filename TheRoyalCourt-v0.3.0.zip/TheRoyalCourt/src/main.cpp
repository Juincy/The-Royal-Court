// The Royal Court | CK3 Mod Manager - native Windows GUI (Win32 + common controls)
#define NOMINMAX
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include "core.hpp"

#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <shlobj.h>

using namespace rc;

static std::wstring W(const std::string& s) {
    if (s.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring w((size_t)n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &w[0], n);
    return w;
}
static std::string U(const std::wstring& w) {
    if (w.empty()) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    std::string s((size_t)n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), &s[0], n, nullptr, nullptr);
    return s;
}
static std::wstring wenv(const wchar_t* name) {
    wchar_t buf[MAX_PATH * 2];
    DWORD n = GetEnvironmentVariableW(name, buf, (DWORD)(sizeof buf / sizeof buf[0]));
    return (n > 0 && n < sizeof buf / sizeof buf[0]) ? std::wstring(buf, n) : L"";
}

enum {
    ID_COMBO = 100, ID_NEW, ID_DUP, ID_REN, ID_DEL, ID_EXPORT, ID_IMPORT, ID_APPLY, ID_LOG, ID_FILTER, ID_ALLON, ID_ALLOFF,
    ID_UP, ID_DOWN, ID_LIST, ID_DIR, ID_BROWSE, ID_SAVEDIR, ID_STATUS, ID_COUNT, ID_L1, ID_L2, ID_L3
};

static HINSTANCE g_inst;
static HWND hMain, hL1, hL2, hL3, hCombo, hNew, hDup, hRen, hDel, hExport, hImport, hApply, hLog, hFilter, hAllOn, hAllOff, hCount,
    hUp, hDown, hList, hStatus, hDir, hBrowse, hSaveDir;
static HFONT g_font;
static int g_dpi = 96;
static Store g_store;
static std::vector<ModInfo> g_mods;
static std::map<std::string, ModInfo> g_info;
static std::vector<int> g_shown;  // list row -> index into active playset mods
static bool g_populating = false;
static bool g_drag = false;
static int g_dragFrom = -1;
static LVINSERTMARK g_mark;
static std::vector<std::string> g_docRoots;

static int S(int v) { return MulDiv(v, g_dpi, 96); }
static void say(const std::wstring& t) { SetWindowTextW(hStatus, t.c_str()); }
static Playset* active() { return findPlayset(g_store, g_store.active); }
static std::string effectiveDir() { return g_store.ck3Dir.empty() ? autoFindCK3Dir(g_docRoots) : g_store.ck3Dir; }
static std::wstring getText(HWND h) {
    int n = GetWindowTextLengthW(h);
    std::wstring s((size_t)n + 1, 0);
    GetWindowTextW(h, &s[0], n + 1);
    s.resize((size_t)n);
    return s;
}
static std::wstring wlower(std::wstring s) { for (auto& c : s) c = (wchar_t)towlower(c); return s; }
static void persist() {
    if (!saveStore(g_store)) say(L"Warning: could not save playsets.json.");
}

// ---------- list ----------
static void updateCount() {
    Playset* ps = active();
    if (!ps) return;
    int on = 0;
    for (auto& m : ps->mods) if (m.enabled) on++;
    std::wstring t = std::to_wstring(on) + L" of " + std::to_wstring(ps->mods.size()) + L" enabled";
    SetWindowTextW(hCount, t.c_str());
}

static void populate() {
    Playset* ps = active();
    if (!ps) return;
    g_populating = true;
    SendMessageW(hList, WM_SETREDRAW, FALSE, 0);
    ListView_DeleteAllItems(hList);
    g_shown.clear();
    std::wstring f = wlower(getText(hFilter));
    for (int i = 0; i < (int)ps->mods.size(); i++) {
        const ModRef& m = ps->mods[(size_t)i];
        auto it = g_info.find(m.id);
        bool inst = it != g_info.end();
        std::wstring name = inst ? W(it->second.name) : W(m.name.empty() ? m.id : m.name) + L"  (not installed)";
        if (!f.empty() && wlower(name).find(f) == std::wstring::npos) continue;
        int row = (int)g_shown.size();
        std::wstring num = std::to_wstring(i + 1);
        LVITEMW li{};
        li.mask = LVIF_TEXT;
        li.iItem = row;
        li.pszText = &num[0];
        ListView_InsertItem(hList, &li);
        ListView_SetItemText(hList, row, 1, (LPWSTR)name.c_str());
        std::wstring ver = inst ? W(it->second.version) : L"", src = inst ? W(it->second.source) : L"";
        ListView_SetItemText(hList, row, 2, (LPWSTR)ver.c_str());
        ListView_SetItemText(hList, row, 3, (LPWSTR)src.c_str());
        ListView_SetCheckState(hList, row, m.enabled ? TRUE : FALSE);
        g_shown.push_back(i);
    }
    SendMessageW(hList, WM_SETREDRAW, TRUE, 0);
    g_populating = false;
    updateCount();
}

static void fillCombo() {
    SendMessageW(hCombo, CB_RESETCONTENT, 0, 0);
    int sel = 0, i = 0;
    for (auto& p : g_store.playsets) {
        SendMessageW(hCombo, CB_ADDSTRING, 0, (LPARAM)W(p.name).c_str());
        if (p.name == g_store.active) sel = i;
        i++;
    }
    SendMessageW(hCombo, CB_SETCURSEL, (WPARAM)sel, 0);
}

static void reload() {
    std::string dir = effectiveDir();
    g_mods = scanMods(dir);
    g_info.clear();
    for (auto& m : g_mods) g_info[m.id] = m;
    syncStore(g_store, g_mods, dir);
    persist();
    SetWindowTextW(hDir, W(dir).c_str());
    fillCombo();
    populate();
    if (dir.empty()) say(L"CK3 folder not found. Enter it below (the folder that contains \"mod\" and dlc_load.json), then press Save folder.");
    else if (g_mods.empty()) say(L"No mods found in " + W(dir) + L"\\mod");
}

static void resizeCols() {
    RECT r; GetClientRect(hList, &r);
    int w = r.right - S(50) - S(100) - S(90) - GetSystemMetrics(SM_CXVSCROLL) - S(4);
    ListView_SetColumnWidth(hList, 1, w < S(150) ? S(150) : w);
}

static void selectRow(int row) {
    ListView_SetItemState(hList, -1, 0, LVIS_SELECTED);
    ListView_SetItemState(hList, row, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
    ListView_EnsureVisible(hList, row, FALSE);
}

static bool filterActive() { return !getText(hFilter).empty(); }

// Move the mod at position `from` so it ends up at position `to` (both indices into the full playset).
static void moveMod(int from, int to) {
    Playset* ps = active();
    if (!ps || from < 0 || to < 0 || from >= (int)ps->mods.size() || to >= (int)ps->mods.size() || from == to) return;
    ModRef m = ps->mods[(size_t)from];
    ps->mods.erase(ps->mods.begin() + from);
    ps->mods.insert(ps->mods.begin() + to, m);
    persist();
    populate();
    selectRow(to);
}

// ---------- small modal text prompt ----------
struct AskCtx { HWND edit = nullptr; std::wstring* out = nullptr; bool done = false, ok = false; };
static LRESULT CALLBACK AskProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    AskCtx* c = (AskCtx*)GetWindowLongPtrW(h, GWLP_USERDATA);
    switch (m) {
        case WM_CREATE: SetWindowLongPtrW(h, GWLP_USERDATA, (LONG_PTR)((CREATESTRUCTW*)l)->lpCreateParams); return 0;
        case WM_COMMAND:
            if (c && LOWORD(w) == IDOK) { *c->out = getText(c->edit); c->ok = true; c->done = true; }
            else if (c && LOWORD(w) == IDCANCEL) c->done = true;
            return 0;
        case WM_CLOSE: if (c) c->done = true; return 0;
    }
    return DefWindowProcW(h, m, w, l);
}
static void setFont(HWND h) { SendMessageW(h, WM_SETFONT, (WPARAM)g_font, TRUE); }

static bool askText(const wchar_t* title, const wchar_t* prompt, std::wstring& value) {
    static bool reg = false;
    if (!reg) {
        WNDCLASSW wc{};
        wc.lpfnWndProc = AskProc; wc.hInstance = g_inst; wc.lpszClassName = L"RCAsk";
        wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1); wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
        RegisterClassW(&wc); reg = true;
    }
    AskCtx ctx; ctx.out = &value;
    RECT pr; GetWindowRect(hMain, &pr);
    int w = S(380), h = S(140);
    int x = pr.left + ((pr.right - pr.left) - w) / 2, y = pr.top + ((pr.bottom - pr.top) - h) / 2;
    HWND d = CreateWindowExW(WS_EX_DLGMODALFRAME, L"RCAsk", title, WS_POPUP | WS_CAPTION | WS_SYSMENU, x, y, w, h, hMain, nullptr, g_inst, &ctx);
    HWND st = CreateWindowW(L"STATIC", prompt, WS_CHILD | WS_VISIBLE, S(12), S(12), S(340), S(20), d, nullptr, g_inst, nullptr);
    ctx.edit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", value.c_str(), WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL, S(12), S(36), S(340), S(24), d, nullptr, g_inst, nullptr);
    HWND ok = CreateWindowW(L"BUTTON", L"OK", WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_DEFPUSHBUTTON, S(190), S(72), S(75), S(26), d, (HMENU)(INT_PTR)IDOK, g_inst, nullptr);
    HWND ca = CreateWindowW(L"BUTTON", L"Cancel", WS_CHILD | WS_VISIBLE | WS_TABSTOP, S(277), S(72), S(75), S(26), d, (HMENU)(INT_PTR)IDCANCEL, g_inst, nullptr);
    setFont(st); setFont(ctx.edit); setFont(ok); setFont(ca);
    SendMessageW(ctx.edit, EM_SETSEL, 0, -1);
    EnableWindow(hMain, FALSE);
    ShowWindow(d, SW_SHOW);
    SetFocus(ctx.edit);
    MSG msg;
    while (!ctx.done && GetMessageW(&msg, nullptr, 0, 0)) {
        if (!IsDialogMessageW(d, &msg)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    }
    EnableWindow(hMain, TRUE);
    DestroyWindow(d);
    SetForegroundWindow(hMain);
    return ctx.ok;
}

static bool nameFree(const std::string& n) { return !n.empty() && !findPlayset(g_store, n); }

// ---------- changelog window ----------
static LRESULT CALLBACK LogProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
        case WM_CREATE: {
            HWND e = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL, 0, 0, 10, 10, h, (HMENU)1, g_inst, nullptr);
            setFont(e);
            std::string txt = "Changelog not found.";
            if (HRSRC r = FindResourceW(nullptr, L"CHANGELOG", MAKEINTRESOURCEW(10))) {  // RT_RCDATA
                if (HGLOBAL g = LoadResource(nullptr, r)) txt.assign((const char*)LockResource(g), SizeofResource(nullptr, r));
            }
            std::string crlf;
            for (size_t i = 0; i < txt.size(); i++) {
                if (txt[i] == '\r') continue;
                if (txt[i] == '\n') crlf += "\r\n"; else crlf += txt[i];
            }
            SetWindowTextW(e, W(crlf).c_str());
            SendMessageW(e, EM_SETSEL, 0, 0);
            return 0;
        }
        case WM_SIZE: { RECT r; GetClientRect(h, &r); MoveWindow(GetDlgItem(h, 1), 0, 0, r.right, r.bottom, TRUE); return 0; }
        case WM_CLOSE: DestroyWindow(h); return 0;
    }
    return DefWindowProcW(h, m, w, l);
}
static void showChangelog() {
    static bool reg = false;
    if (!reg) {
        WNDCLASSW wc{};
        wc.lpfnWndProc = LogProc; wc.hInstance = g_inst; wc.lpszClassName = L"RCLog";
        wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1); wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
        RegisterClassW(&wc); reg = true;
    }
    HWND w = CreateWindowExW(0, L"RCLog", L"Changelog - The Royal Court", WS_OVERLAPPEDWINDOW | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT, S(640), S(520), hMain, nullptr, g_inst, nullptr);
    (void)w;
}

// ---------- folder picker ----------
static void browseFolder() {
    BROWSEINFOW bi{};
    bi.hwndOwner = hMain;
    bi.lpszTitle = L"Select your Crusader Kings III folder (the one that contains \"mod\")";
    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    if (PIDLIST_ABSOLUTE pidl = SHBrowseForFolderW(&bi)) {
        wchar_t path[MAX_PATH];
        if (SHGetPathFromIDListW(pidl, path)) SetWindowTextW(hDir, path);
        CoTaskMemFree(pidl);
    }
}

// ---------- file dialogs ----------
static bool pickFile(bool save, const std::wstring& suggested, std::wstring& out) {
    wchar_t buf[MAX_PATH * 2] = {0};
    wcsncpy(buf, suggested.c_str(), MAX_PATH - 1);
    OPENFILENAMEW o{};
    o.lStructSize = sizeof o;
    o.hwndOwner = hMain;
    o.lpstrFilter = L"Royal Court playset (*.json)\0*.json\0All files (*.*)\0*.*\0";
    o.lpstrFile = buf;
    o.nMaxFile = (DWORD)(sizeof buf / sizeof buf[0]);
    o.lpstrDefExt = L"json";
    o.Flags = OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR | (save ? OFN_OVERWRITEPROMPT : OFN_FILEMUSTEXIST);
    BOOL ok = save ? GetSaveFileNameW(&o) : GetOpenFileNameW(&o);
    if (!ok) return false;
    out = buf;
    return true;
}

// ---------- layout ----------
static void place(HWND h, int x, int y, int w, int hgt) { SetWindowPos(h, nullptr, x, y, w, hgt, SWP_NOZORDER | SWP_NOACTIVATE); }

static void layout() {
    RECT rc; GetClientRect(hMain, &rc);
    int Wd = rc.right, Ht = rc.bottom;
    int m = S(10), rowH = S(26), gap = S(6);
    int y = m, x = m;
    place(hL1, x, y + S(4), S(55), S(20)); x += S(58);
    place(hCombo, x, y, S(200), S(300)); x += S(200) + gap;
    place(hNew, x, y, S(60), rowH); x += S(60) + gap;
    place(hDup, x, y, S(80), rowH); x += S(80) + gap;
    place(hRen, x, y, S(70), rowH); x += S(70) + gap;
    place(hDel, x, y, S(60), rowH); x += S(60) + gap * 2;
    place(hExport, x, y, S(80), rowH); x += S(80) + gap;
    place(hImport, x, y, S(80), rowH);
    int rx = Wd - m - S(90);
    place(hLog, rx, y, S(90), rowH);
    rx -= gap + S(130);
    place(hApply, rx, y, S(130), rowH);

    y += rowH + gap + S(4); x = m;
    place(hL2, x, y + S(5), S(40), S(20)); x += S(44);
    place(hFilter, x, y, S(200), rowH - S(2)); x += S(200) + gap;
    place(hAllOn, x, y, S(110), rowH); x += S(110) + gap;
    place(hAllOff, x, y, S(110), rowH); x += S(110) + gap * 2;
    place(hCount, x, y + S(5), S(170), S(20));
    rx = Wd - m - S(80);
    place(hDown, rx, y, S(80), rowH);
    rx -= gap + S(80);
    place(hUp, rx, y, S(80), rowH);

    y += rowH + gap + S(2);
    int bottom = Ht - m - rowH - gap - S(22) - gap;
    place(hList, m, y, Wd - 2 * m, bottom - y);
    int sy = bottom + gap;
    place(hStatus, m, sy, Wd - 2 * m, S(20));
    int dy = sy + S(22) + gap;
    place(hL3, m, dy + S(5), S(80), S(20));
    place(hDir, m + S(84), dy, Wd - 2 * m - S(84) - 2 * (S(90) + gap), rowH - S(2));
    place(hBrowse, Wd - m - 2 * S(90) - gap, dy, S(90), rowH);
    place(hSaveDir, Wd - m - S(90), dy, S(90), rowH);
    resizeCols();
}

static HWND mk(const wchar_t* cls, const wchar_t* text, DWORD style, int id, DWORD ex = 0) {
    HWND h = CreateWindowExW(ex, cls, text, WS_CHILD | WS_VISIBLE | style, 0, 0, 10, 10, hMain, (HMENU)(INT_PTR)id, g_inst, nullptr);
    setFont(h);
    return h;
}

static void createControls() {
    hL1 = mk(L"STATIC", L"Playset:", 0, ID_L1);
    hCombo = mk(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_VSCROLL | WS_TABSTOP, ID_COMBO);
    hNew = mk(L"BUTTON", L"New...", WS_TABSTOP, ID_NEW);
    hDup = mk(L"BUTTON", L"Duplicate...", WS_TABSTOP, ID_DUP);
    hRen = mk(L"BUTTON", L"Rename...", WS_TABSTOP, ID_REN);
    hDel = mk(L"BUTTON", L"Delete", WS_TABSTOP, ID_DEL);
    hExport = mk(L"BUTTON", L"Export...", WS_TABSTOP, ID_EXPORT);
    hImport = mk(L"BUTTON", L"Import...", WS_TABSTOP, ID_IMPORT);
    hApply = mk(L"BUTTON", L"Apply playset", WS_TABSTOP, ID_APPLY);
    hLog = mk(L"BUTTON", L"Changelog", WS_TABSTOP, ID_LOG);
    hL2 = mk(L"STATIC", L"Filter:", 0, ID_L2);
    hFilter = mk(L"EDIT", L"", ES_AUTOHSCROLL | WS_TABSTOP, ID_FILTER, WS_EX_CLIENTEDGE);
    hAllOn = mk(L"BUTTON", L"Enable shown", WS_TABSTOP, ID_ALLON);
    hAllOff = mk(L"BUTTON", L"Disable shown", WS_TABSTOP, ID_ALLOFF);
    hCount = mk(L"STATIC", L"", 0, ID_COUNT);
    hUp = mk(L"BUTTON", L"Move up", WS_TABSTOP, ID_UP);
    hDown = mk(L"BUTTON", L"Move down", WS_TABSTOP, ID_DOWN);
    hList = mk(WC_LISTVIEWW, L"", LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS | WS_TABSTOP, ID_LIST, WS_EX_CLIENTEDGE);
    ListView_SetExtendedListViewStyle(hList, LVS_EX_CHECKBOXES | LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER);
    const wchar_t* heads[4] = {L"#", L"Mod", L"Version", L"Source"};
    int widths[4] = {S(50), S(400), S(100), S(90)};
    for (int i = 0; i < 4; i++) {
        LVCOLUMNW c{};
        c.mask = LVCF_TEXT | LVCF_WIDTH;
        c.pszText = (LPWSTR)heads[i];
        c.cx = widths[i];
        ListView_InsertColumn(hList, i, &c);
    }
    hStatus = mk(L"STATIC", L"", SS_ENDELLIPSIS, ID_STATUS);
    hL3 = mk(L"STATIC", L"CK3 folder:", 0, ID_L3);
    hDir = mk(L"EDIT", L"", ES_AUTOHSCROLL | WS_TABSTOP, ID_DIR, WS_EX_CLIENTEDGE);
    hBrowse = mk(L"BUTTON", L"Browse...", WS_TABSTOP, ID_BROWSE);
    hSaveDir = mk(L"BUTTON", L"Save folder", WS_TABSTOP, ID_SAVEDIR);
}

static void setShown(bool on) {
    Playset* ps = active();
    if (!ps) return;
    for (int idx : g_shown) ps->mods[(size_t)idx].enabled = on;
    persist();
    populate();
}

static void onCommand(int id, int code) {
    Playset* ps = active();
    switch (id) {
        case ID_COMBO:
            if (code == CBN_SELCHANGE) {
                int i = (int)SendMessageW(hCombo, CB_GETCURSEL, 0, 0);
                if (i >= 0 && i < (int)g_store.playsets.size()) { g_store.active = g_store.playsets[(size_t)i].name; persist(); populate(); }
            }
            break;
        case ID_FILTER: if (code == EN_CHANGE) populate(); break;
        case ID_ALLON: setShown(true); break;
        case ID_ALLOFF: setShown(false); break;
        case ID_NEW: {
            std::wstring v;
            if (askText(L"New playset", L"Name for the new playset:", v)) {
                std::string n = U(v);
                if (!nameFree(n)) { MessageBoxW(hMain, L"That name is empty or already used.", L"The Royal Court", MB_ICONINFORMATION); break; }
                Playset p; p.name = n;
                for (auto& m : g_mods) p.mods.push_back({m.id, false, m.name});
                g_store.playsets.push_back(p); g_store.active = n; persist(); fillCombo(); populate();
            }
            break;
        }
        case ID_DUP: {
            if (!ps) break;
            std::wstring v = W(ps->name) + L" copy";
            if (askText(L"Duplicate playset", L"Name for the copy:", v)) {
                std::string n = U(v);
                if (!nameFree(n)) { MessageBoxW(hMain, L"That name is empty or already used.", L"The Royal Court", MB_ICONINFORMATION); break; }
                Playset p = *ps; p.name = n;
                g_store.playsets.push_back(p); g_store.active = n; persist(); fillCombo(); populate();
            }
            break;
        }
        case ID_REN: {
            if (!ps) break;
            std::wstring v = W(ps->name);
            if (askText(L"Rename playset", L"New name:", v)) {
                std::string n = U(v);
                if (!nameFree(n)) { MessageBoxW(hMain, L"That name is empty or already used.", L"The Royal Court", MB_ICONINFORMATION); break; }
                ps->name = n; g_store.active = n; persist(); fillCombo();
            }
            break;
        }
        case ID_DEL: {
            if (!ps) break;
            if (g_store.playsets.size() < 2) { MessageBoxW(hMain, L"You need at least one playset.", L"The Royal Court", MB_ICONINFORMATION); break; }
            std::wstring q = L"Delete playset \"" + W(ps->name) + L"\"?";
            if (MessageBoxW(hMain, q.c_str(), L"The Royal Court", MB_YESNO | MB_ICONQUESTION) != IDYES) break;
            std::string gone = ps->name;
            g_store.playsets.erase(std::remove_if(g_store.playsets.begin(), g_store.playsets.end(), [&](const Playset& p) { return p.name == gone; }), g_store.playsets.end());
            g_store.active = g_store.playsets[0].name; persist(); fillCombo(); populate();
            break;
        }
        case ID_EXPORT: {
            if (!ps) break;
            std::wstring path;
            if (!pickFile(true, W(sanitizeFileName(ps->name)) + L".json", path)) break;
            if (!writeFile(P(U(path)), exportPlayset(*ps, g_info))) { MessageBoxW(hMain, L"Could not write that file.", L"The Royal Court", MB_ICONWARNING); break; }
            int n = 0;
            for (auto& m : ps->mods) if (m.enabled) n++;
            say(L"Exported \"" + W(ps->name) + L"\" (" + std::to_wstring(n) + L" enabled mods) to " + path);
            break;
        }
        case ID_IMPORT: {
            std::wstring path;
            if (!pickFile(false, L"", path)) break;
            std::string text;
            if (!readFile(P(U(path)), text)) { MessageBoxW(hMain, L"Could not read that file.", L"The Royal Court", MB_ICONWARNING); break; }
            ImportResult r = parsePlaysetFile(text);
            if (!r.ok) { MessageBoxW(hMain, W(r.error).c_str(), L"The Royal Court", MB_ICONWARNING); break; }
            Playset p = r.playset;
            p.name = uniqueName(g_store, p.name);
            int missing = 0;
            for (auto& m : p.mods) if (!g_info.count(m.id)) missing++;
            g_store.playsets.push_back(p);
            g_store.active = p.name;
            syncStore(g_store, g_mods, effectiveDir());
            persist(); fillCombo(); populate();
            std::wstring msg = L"Imported \"" + W(p.name) + L"\": " + std::to_wstring(p.mods.size()) + L" mods";
            if (missing) msg += L", " + std::to_wstring(missing) + L" not installed (shown in the list; they are skipped on apply)";
            if (r.invalid) msg += L"; " + std::to_wstring(r.invalid) + L" invalid entries ignored";
            say(msg + L".");
            break;
        }
        case ID_UP:
        case ID_DOWN: {
            if (filterActive()) { say(L"Clear the filter to change load order."); break; }
            int row = ListView_GetNextItem(hList, -1, LVNI_SELECTED);
            if (row < 0) { say(L"Select a mod first."); break; }
            moveMod(row, id == ID_UP ? row - 1 : row + 1);
            break;
        }
        case ID_APPLY: {
            if (!ps) break;
            persist();
            std::set<std::string> inst;
            for (auto& m : g_mods) inst.insert(m.id);
            ApplyResult r = applyPlayset(effectiveDir(), *ps, inst);
            say(W(r.message));
            if (!r.ok) MessageBoxW(hMain, W(r.message).c_str(), L"The Royal Court", MB_ICONWARNING);
            break;
        }
        case ID_LOG: showChangelog(); break;
        case ID_BROWSE: browseFolder(); break;
        case ID_SAVEDIR: {
            g_store.ck3Dir = U(getText(hDir));
            persist(); reload();
            if (!effectiveDir().empty()) say(L"Folder saved. Found " + std::to_wstring(g_mods.size()) + L" installed mods.");
            break;
        }
    }
}

static LRESULT onNotify(LPARAM l) {
    NMHDR* h = (NMHDR*)l;
    if (h->hwndFrom != hList) return 0;
    NMLISTVIEW* nm = (NMLISTVIEW*)l;
    if (h->code == LVN_ITEMCHANGED) {
        if (!g_populating && (nm->uChanged & LVIF_STATE) && ((nm->uNewState ^ nm->uOldState) & LVIS_STATEIMAGEMASK)) {
            Playset* ps = active();
            if (ps && nm->iItem >= 0 && nm->iItem < (int)g_shown.size()) {
                ps->mods[(size_t)g_shown[(size_t)nm->iItem]].enabled = ListView_GetCheckState(hList, nm->iItem) != 0;
                persist();
                updateCount();
            }
        }
    } else if (h->code == LVN_BEGINDRAG) {
        if (filterActive()) { say(L"Clear the filter to change load order."); return 0; }
        g_drag = true; g_dragFrom = nm->iItem;
        g_mark = LVINSERTMARK{sizeof(LVINSERTMARK), 0, -1, 0};
        SetCapture(hMain);
    }
    return 0;
}

static void endDrag(bool drop) {
    if (!g_drag) return;
    g_drag = false;
    ReleaseCapture();
    LVINSERTMARK none{sizeof(LVINSERTMARK), 0, -1, 0};
    ListView_SetInsertMark(hList, &none);
    if (drop && g_mark.iItem >= 0 && g_dragFrom >= 0) {
        int to = g_mark.iItem + ((g_mark.dwFlags & LVIM_AFTER) ? 1 : 0);
        if (to > g_dragFrom) to--;
        moveMod(g_dragFrom, to);
    }
    g_dragFrom = -1;
}

static LRESULT CALLBACK MainProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
        case WM_CREATE: hMain = h; createControls(); return 0;
        case WM_SIZE: layout(); return 0;
        case WM_GETMINMAXINFO: { auto* mi = (MINMAXINFO*)l; mi->ptMinTrackSize.x = S(960); mi->ptMinTrackSize.y = S(420); return 0; }
        case WM_COMMAND:
            if (LOWORD(w) == IDOK || LOWORD(w) == IDCANCEL) return 0;
            onCommand(LOWORD(w), HIWORD(w));
            return 0;
        case WM_NOTIFY: return onNotify(l);
        case WM_MOUSEMOVE:
            if (g_drag) {
                POINT pt{(short)LOWORD(l), (short)HIWORD(l)};
                MapWindowPoints(hMain, hList, &pt, 1);
                LVINSERTMARK im{sizeof(LVINSERTMARK), 0, -1, 0};
                if (ListView_InsertMarkHitTest(hList, &pt, &im)) g_mark = im; else g_mark.iItem = -1;
                ListView_SetInsertMark(hList, &g_mark);
                SetCursor(LoadCursor(nullptr, IDC_SIZENS));
            }
            return 0;
        case WM_LBUTTONUP: endDrag(true); return 0;
        case WM_CAPTURECHANGED: if (g_drag) endDrag(false); return 0;
        case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE, PWSTR, int show) {
    g_inst = inst;
    INITCOMMONCONTROLSEX icc{sizeof(icc), ICC_LISTVIEW_CLASSES | ICC_STANDARD_CLASSES};
    InitCommonControlsEx(&icc);
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    HDC dc = GetDC(nullptr);
    g_dpi = GetDeviceCaps(dc, LOGPIXELSX);
    ReleaseDC(nullptr, dc);
    NONCLIENTMETRICSW ncm{};
    ncm.cbSize = sizeof ncm;
    SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, sizeof ncm, &ncm, 0);
    g_font = CreateFontIndirectW(&ncm.lfMessageFont);

    g_appData = U(wenv(L"APPDATA"));
    PWSTR docs = nullptr;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_Documents, 0, nullptr, &docs)) && docs) { g_docRoots.push_back(U(docs)); CoTaskMemFree(docs); }
    std::wstring up = wenv(L"USERPROFILE");
    if (!up.empty()) g_docRoots.push_back(U(up) + "/Documents");
    for (const wchar_t* e : {L"OneDrive", L"OneDriveConsumer", L"OneDriveCommercial"}) {
        std::wstring v = wenv(e);
        if (!v.empty()) g_docRoots.push_back(U(v) + "/Documents");
    }

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof wc;
    wc.lpfnWndProc = MainProc; wc.hInstance = inst; wc.lpszClassName = L"RoyalCourtMain";
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1); wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hIcon = (HICON)LoadImageW(inst, MAKEINTRESOURCEW(1), IMAGE_ICON, GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
    wc.hIconSm = (HICON)LoadImageW(inst, MAKEINTRESOURCEW(1), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
    RegisterClassExW(&wc);

    std::wstring title = L"The Royal Court | CK3 Mod Manager  v" + W(VERSION);
    HWND win = CreateWindowExW(WS_EX_CONTROLPARENT, L"RoyalCourtMain", title.c_str(), WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, S(1040), S(660), nullptr, nullptr, inst, nullptr);
    if (!win) return 1;

    loadStore(g_store);
    reload();
    ShowWindow(win, show);
    UpdateWindow(win);

    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        if (!IsDialogMessageW(win, &msg)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    }
    return (int)msg.wParam;
}
