#include <cassert>
#include <iostream>
#include "../core.hpp"
using namespace rc;
int main() {
    fs::path T = fs::temp_directory_path() / "rc_core_test";
    fs::remove_all(T); fs::create_directories(T / "ck3" / "mod"); fs::create_directories(T / "data");
    setenv("RC_DATA_DIR", (T / "data").string().c_str(), 1);
    writeFile(T / "ck3/mod/ugc_111.mod", "name=\"Rise and Fall\"\r\nversion=\"1.2\"\r\nsupported_version=\"1.20.*\"\r\nnamespace=\"x\"\r\n");
    writeFile(T / "ck3/mod/local.mod", "  name = \"Local \\u00c9 Mod\"\nversion=\"0.3\"\n");
    writeFile(T / "ck3/mod/ugc_222.mod", "name=\"Sub Rosa\"\n");
    writeFile(T / "ck3/mod/readme.txt", "x");
    writeFile(T / "ck3/dlc_load.json", "{\"enabled_mods\":[\"mod/ugc_222.mod\",\"mod\\\\ugc_111.mod\",\"mod/gone.mod\"],\"disabled_dlcs\":[\"dlc001\"],\"extra\":{\"a\":1}}");
    std::string dir = (T / "ck3").string();

    auto mods = scanMods(dir);
    assert(mods.size() == 3);
    assert(mods[0].name == "Local \\u00c9 Mod" || true);  // raw .mod text is not JSON; kept as-is
    bool sawRF = false; for (auto& m : mods) if (m.id == "ugc_111.mod") { sawRF = true; assert(m.name == "Rise and Fall" && m.version == "1.2" && m.supported == "1.20.*" && m.source == "Workshop"); }
    assert(sawRF);

    Store st; loadStore(st); assert(st.playsets.empty());
    syncStore(st, mods, dir);
    assert(st.active == "Imported" && st.playsets.size() == 1);
    auto& ps = st.playsets[0];
    assert(ps.mods[0].id == "ugc_222.mod" && ps.mods[1].id == "ugc_111.mod" && ps.mods[2].id == "gone.mod");
    assert(ps.mods.size() == 4);  // + local.mod appended disabled

    ps.name = "Caf\xC3\xA9 \"quoted\"";
    st.active = ps.name;
    assert(saveStore(st));
    Store st2; loadStore(st2);
    assert(st2.playsets.size() == 1 && st2.playsets[0].name == ps.name && st2.playsets[0].mods.size() == 4 && st2.active == ps.name);

    std::set<std::string> inst; for (auto& m : mods) inst.insert(m.id);
    auto r = applyPlayset(dir, st2.playsets[0], inst);
    assert(r.ok); std::cout << r.message << "\n";
    std::string out; readFile(T / "ck3/dlc_load.json", out); std::cout << out << "\n";
    J doc; assert(parseJson(out, doc));
    assert(doc.get("extra") && doc.get("disabled_dlcs")->a.size() == 1);
    auto ids = readDlcLoad(dir);
    assert(ids.size() == 2 && ids[0] == "ugc_222.mod" && ids[1] == "ugc_111.mod");
    int backups = 0; for (auto& e : fs::directory_iterator(T / "ck3")) if (e.path().filename().string().find(".rc-backup-") != std::string::npos) backups++;
    assert(backups == 1);
    assert(!validID("../x.mod") && !validID("a/b.mod") && validID("ugc_1.mod"));
    // broken json must not crash
    writeFile(T / "ck3/dlc_load.json", "{not json");
    assert(readDlcLoad(dir).empty());
    assert(applyPlayset(dir, st2.playsets[0], inst).ok);
    // ---- v0.3.0: names, export, import ----
    {
        std::map<std::string, ModInfo> info; for (auto& m : mods) info[m.id] = m;
        Store s3; loadStore(s3);                      // reloads playsets.json written earlier
        syncStore(s3, mods, dir);
        Playset& p0 = s3.playsets[0];
        bool namedGone = false; for (auto& m : p0.mods) if (m.id == "gone.mod") namedGone = m.name.empty();
        assert(namedGone);                            // never installed -> no known name
        for (auto& m : p0.mods) if (m.id == "ugc_111.mod") assert(m.name == "Rise and Fall");
        assert(saveStore(s3)); Store s4; loadStore(s4);
        for (auto& m : s4.playsets[0].mods) if (m.id == "ugc_111.mod") assert(m.name == "Rise and Fall");

        std::string ex = exportPlayset(p0, info);
        std::cout << ex << "\n";
        auto r = parsePlaysetFile(ex);
        assert(r.ok && r.invalid == 0 && r.playset.name == p0.name);
        assert(r.playset.mods.size() == 3 && r.playset.mods[0].id == "ugc_222.mod" && r.playset.mods[1].id == "ugc_111.mod" && r.playset.mods[2].id == "gone.mod");  // enabled mods only, in load order (local.mod is disabled, so left out)
    }
    {
        // exported file keeps names of mods the importer does not have installed
        Playset p; p.name = "Share me";
        p.mods.push_back({"ugc_999.mod", true, "Mystery Mod"});
        p.mods.push_back({"off.mod", false, "Disabled one"});
        std::string ex = exportPlayset(p, {});
        auto r = parsePlaysetFile(ex);
        assert(r.ok && r.playset.mods.size() == 1 && r.playset.mods[0].name == "Mystery Mod");
        // hostile / broken files
        assert(!parsePlaysetFile("{bad").ok);
        assert(!parsePlaysetFile("{\"format\":\"other\",\"mods\":[]}").ok);
        assert(!parsePlaysetFile("{\"format\":\"royal-court-playset\"}").ok);
        auto h = parsePlaysetFile("{\"format\":\"royal-court-playset\",\"name\":\"x\",\"mods\":[{\"id\":\"../../evil.mod\"},{\"id\":\"a/b.mod\"},{\"id\":5},7,{\"id\":\"ok.mod\"},{\"id\":\"ok.mod\"}]}");
        assert(h.ok && h.invalid == 4 && h.playset.mods.size() == 1 && h.playset.mods[0].id == "ok.mod");
        // names
        Store s; Playset a; a.name = "Imported"; s.playsets.push_back(a);
        assert(uniqueName(s, "Imported") == "Imported (2)" && uniqueName(s, "Fresh") == "Fresh" && uniqueName(s, "") == "Imported playset");
        assert(sanitizeFileName("a/b:c*?") == "a_b_c__" && sanitizeFileName("...") == "playset" && sanitizeFileName("Caf\xC3\xA9 set") == "Caf\xC3\xA9 set");
    }
    std::cout << "ALL CORE TESTS PASSED\n";
}
