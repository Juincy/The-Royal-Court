// The Royal Court | CK3 Mod Manager - core logic (no Windows APIs, testable anywhere)
#pragma once
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace rc {

inline const char* VERSION = "0.3.0";
inline std::string g_appData;  // set by the GUI (%APPDATA%), UTF-8

// ---------- small helpers ----------
inline fs::path P(const std::string& s) { return fs::u8path(s); }

inline bool readFile(const fs::path& p, std::string& out) {
    std::ifstream f(p, std::ios::binary);
    if (!f) return false;
    std::ostringstream ss;
    ss << f.rdbuf();
    out = ss.str();
    return true;
}
inline bool writeFile(const fs::path& p, const std::string& data) {
    std::ofstream f(p, std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f.write(data.data(), (std::streamsize)data.size());
    return (bool)f;
}
inline std::string lower(std::string s) {
    for (auto& c : s) if ((unsigned char)c < 128) c = (char)tolower((unsigned char)c);
    return s;
}

// ---------- minimal JSON ----------
struct J {
    enum T { Null, Bool, Num, Str, Arr, Obj } t = Null;
    bool b = false;
    double n = 0;
    std::string s;
    std::vector<J> a;
    std::vector<std::string> keys;
    std::vector<J> vals;
    static J str(std::string v) { J j; j.t = Str; j.s = std::move(v); return j; }
    static J num(double v) { J j; j.t = Num; j.n = v; return j; }
    static J boolean(bool v) { J j; j.t = Bool; j.b = v; return j; }
    static J arr() { J j; j.t = Arr; return j; }
    static J obj() { J j; j.t = Obj; return j; }
    J* get(const std::string& k) {
        for (size_t i = 0; i < keys.size(); i++) if (keys[i] == k) return &vals[i];
        return nullptr;
    }
    void set(const std::string& k, J v) {
        if (J* p = get(k)) *p = std::move(v);
        else { keys.push_back(k); vals.push_back(std::move(v)); }
    }
};

struct Parser {
    const std::string& s;
    size_t p = 0;
    bool ok = true;
    explicit Parser(const std::string& str) : s(str) {}
    void ws() { while (p < s.size() && (s[p] == ' ' || s[p] == '\t' || s[p] == '\n' || s[p] == '\r')) p++; }
    static void utf8(std::string& o, unsigned c) {
        if (c < 0x80) o += (char)c;
        else if (c < 0x800) { o += (char)(0xC0 | (c >> 6)); o += (char)(0x80 | (c & 0x3F)); }
        else if (c < 0x10000) { o += (char)(0xE0 | (c >> 12)); o += (char)(0x80 | ((c >> 6) & 0x3F)); o += (char)(0x80 | (c & 0x3F)); }
        else { o += (char)(0xF0 | (c >> 18)); o += (char)(0x80 | ((c >> 12) & 0x3F)); o += (char)(0x80 | ((c >> 6) & 0x3F)); o += (char)(0x80 | (c & 0x3F)); }
    }
    unsigned hex4() {
        unsigned v = 0;
        for (int i = 0; i < 4 && p < s.size(); i++) {
            char c = s[p++]; v <<= 4;
            if (c >= '0' && c <= '9') v |= c - '0';
            else if (c >= 'a' && c <= 'f') v |= c - 'a' + 10;
            else if (c >= 'A' && c <= 'F') v |= c - 'A' + 10;
            else ok = false;
        }
        return v;
    }
    std::string str() {
        std::string o; p++;
        while (p < s.size() && s[p] != '"') {
            char c = s[p++];
            if (c == '\\' && p < s.size()) {
                char e = s[p++];
                switch (e) {
                    case 'n': o += '\n'; break;
                    case 't': o += '\t'; break;
                    case 'r': o += '\r'; break;
                    case 'b': o += '\b'; break;
                    case 'f': o += '\f'; break;
                    case 'u': {
                        unsigned cp = hex4();
                        if (cp >= 0xD800 && cp < 0xDC00 && p + 1 < s.size() && s[p] == '\\' && s[p + 1] == 'u') {
                            p += 2; unsigned lo = hex4();
                            cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                        }
                        utf8(o, cp); break;
                    }
                    default: o += e;
                }
            } else o += c;
        }
        if (p < s.size()) p++; else ok = false;
        return o;
    }
    J val(int depth = 0) {
        ws();
        J j;
        if (p >= s.size() || depth > 64) { ok = false; return j; }
        char c = s[p];
        if (c == '{') {
            j.t = J::Obj; p++; ws();
            if (p < s.size() && s[p] == '}') { p++; return j; }
            while (ok) {
                ws();
                if (p >= s.size() || s[p] != '"') { ok = false; break; }
                std::string k = str(); ws();
                if (p >= s.size() || s[p] != ':') { ok = false; break; }
                p++;
                J v = val(depth + 1);
                j.keys.push_back(k); j.vals.push_back(std::move(v)); ws();
                if (p < s.size() && s[p] == ',') { p++; continue; }
                if (p < s.size() && s[p] == '}') { p++; break; }
                ok = false;
            }
        } else if (c == '[') {
            j.t = J::Arr; p++; ws();
            if (p < s.size() && s[p] == ']') { p++; return j; }
            while (ok) {
                j.a.push_back(val(depth + 1)); ws();
                if (p < s.size() && s[p] == ',') { p++; continue; }
                if (p < s.size() && s[p] == ']') { p++; break; }
                ok = false;
            }
        } else if (c == '"') { j.t = J::Str; j.s = str(); }
        else if (s.compare(p, 4, "true") == 0) { j.t = J::Bool; j.b = true; p += 4; }
        else if (s.compare(p, 5, "false") == 0) { j.t = J::Bool; p += 5; }
        else if (s.compare(p, 4, "null") == 0) { p += 4; }
        else {
            char* e; j.n = strtod(s.c_str() + p, &e);
            if (e == s.c_str() + p) ok = false; else { j.t = J::Num; p = (size_t)(e - s.c_str()); }
        }
        return j;
    }
};

inline bool parseJson(const std::string& text, J& out) {
    Parser ps(text);
    if (text.size() >= 3 && (unsigned char)text[0] == 0xEF && (unsigned char)text[1] == 0xBB && (unsigned char)text[2] == 0xBF) ps.p = 3;
    out = ps.val();
    return ps.ok && out.t != J::Null;
}

inline void dumpStr(std::string& o, const std::string& s) {
    o += '"';
    for (unsigned char c : s) {
        switch (c) {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default:
                if (c < 0x20) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; }
                else o += (char)c;
        }
    }
    o += '"';
}
inline void dump(const J& j, std::string& o, int ind = 0) {
    switch (j.t) {
        case J::Null: o += "null"; break;
        case J::Bool: o += j.b ? "true" : "false"; break;
        case J::Num: { char b[40]; snprintf(b, sizeof b, "%.15g", j.n); o += b; break; }
        case J::Str: dumpStr(o, j.s); break;
        case J::Arr:
            if (j.a.empty()) { o += "[]"; break; }
            o += "[\n";
            for (size_t i = 0; i < j.a.size(); i++) {
                o.append((size_t)ind + 1, '\t'); dump(j.a[i], o, ind + 1);
                if (i + 1 < j.a.size()) o += ',';
                o += '\n';
            }
            o.append((size_t)ind, '\t'); o += ']';
            break;
        case J::Obj:
            if (j.keys.empty()) { o += "{}"; break; }
            o += "{\n";
            for (size_t i = 0; i < j.keys.size(); i++) {
                o.append((size_t)ind + 1, '\t'); dumpStr(o, j.keys[i]); o += ": "; dump(j.vals[i], o, ind + 1);
                if (i + 1 < j.keys.size()) o += ',';
                o += '\n';
            }
            o.append((size_t)ind, '\t'); o += '}';
            break;
    }
}

// ---------- data model ----------
struct ModRef { std::string id; bool enabled = false; std::string name; };  // name = last known display name
struct Playset { std::string name; std::vector<ModRef> mods; };
struct ModInfo { std::string id, name, version, supported, source; };
struct Store { std::string active, ck3Dir; std::vector<Playset> playsets; };

inline Playset* findPlayset(Store& st, const std::string& name) {
    for (auto& p : st.playsets) if (p.name == name) return &p;
    return nullptr;
}

// ---------- store on disk ----------
inline std::string dataDir() {
    std::string d;
    if (const char* e = getenv("RC_DATA_DIR"); e && *e) d = e;
    else d = (g_appData.empty() ? std::string(".") : g_appData) + "/TheRoyalCourt";
    std::error_code ec;
    fs::create_directories(P(d), ec);
    return d;
}
inline fs::path storePath() { return P(dataDir()) / "playsets.json"; }

inline J toJson(const Store& st) {
    J root = J::obj();
    root.set("active", J::str(st.active));
    root.set("ck3Dir", J::str(st.ck3Dir));
    J pl = J::arr();
    for (auto& p : st.playsets) {
        J po = J::obj();
        po.set("name", J::str(p.name));
        J ms = J::arr();
        for (auto& m : p.mods) {
            J mo = J::obj();
            mo.set("id", J::str(m.id));
            mo.set("enabled", J::boolean(m.enabled));
            if (!m.name.empty()) mo.set("name", J::str(m.name));
            ms.a.push_back(std::move(mo));
        }
        po.set("mods", std::move(ms));
        pl.a.push_back(std::move(po));
    }
    root.set("playsets", std::move(pl));
    return root;
}
inline void loadStore(Store& st) {
    st = Store{};
    std::string text; J root;
    if (!readFile(storePath(), text) || !parseJson(text, root) || root.t != J::Obj) return;
    if (J* a = root.get("active"); a && a->t == J::Str) st.active = a->s;
    if (J* d = root.get("ck3Dir"); d && d->t == J::Str) st.ck3Dir = d->s;
    if (J* pl = root.get("playsets"); pl && pl->t == J::Arr) {
        for (auto& po : pl->a) {
            if (po.t != J::Obj) continue;
            Playset ps;
            if (J* n = po.get("name"); n && n->t == J::Str) ps.name = n->s;
            if (ps.name.empty()) continue;
            if (J* ms = po.get("mods"); ms && ms->t == J::Arr) {
                for (auto& mo : ms->a) {
                    if (mo.t != J::Obj) continue;
                    ModRef m;
                    if (J* i = mo.get("id"); i && i->t == J::Str) m.id = i->s;
                    if (J* e = mo.get("enabled"); e && e->t == J::Bool) m.enabled = e->b;
                    if (J* nm = mo.get("name"); nm && nm->t == J::Str) m.name = nm->s;
                    if (!m.id.empty()) ps.mods.push_back(m);
                }
            }
            st.playsets.push_back(std::move(ps));
        }
    }
}
inline bool saveStore(const Store& st) {
    std::string out; dump(toJson(st), out); out += "\n";
    fs::path p = storePath(), tmp = p; tmp += ".tmp";
    if (!writeFile(tmp, out)) return false;
    std::error_code ec;
    fs::rename(tmp, p, ec);
    if (ec) { bool ok = writeFile(p, out); fs::remove(tmp, ec); return ok; }
    return true;
}

// ---------- CK3 folder / mods ----------
inline std::string autoFindCK3Dir(const std::vector<std::string>& docRoots) {
    if (const char* e = getenv("RC_CK3_DIR"); e && *e) return e;
    for (auto& r : docRoots) {
        fs::path c = P(r) / "Paradox Interactive" / "Crusader Kings III";
        std::error_code ec;
        if (fs::is_directory(c, ec)) return c.u8string();
    }
    return "";
}

inline bool keyLine(const std::string& line, const std::string& key, std::string& val) {
    size_t i = 0;
    auto skip = [&] { while (i < line.size() && (line[i] == ' ' || line[i] == '\t')) i++; };
    skip();
    if (line.compare(i, key.size(), key) != 0) return false;
    i += key.size(); skip();
    if (i >= line.size() || line[i] != '=') return false;
    i++; skip();
    if (i >= line.size() || line[i] != '"') return false;
    i++;
    size_t e = line.find('"', i);
    if (e == std::string::npos) return false;
    val = line.substr(i, e - i);
    return true;
}

inline std::vector<ModInfo> scanMods(const std::string& dir) {
    std::vector<ModInfo> out;
    if (dir.empty()) return out;
    std::error_code ec;
    fs::path md = P(dir) / "mod";
    if (!fs::is_directory(md, ec)) return out;
    for (auto& e : fs::directory_iterator(md, ec)) {
        if (!e.is_regular_file(ec)) continue;
        std::string ext = lower(e.path().extension().u8string());
        if (ext != ".mod") continue;
        std::string text;
        if (!readFile(e.path(), text)) continue;
        ModInfo mi;
        mi.id = e.path().filename().u8string();
        mi.source = mi.id.rfind("ugc_", 0) == 0 ? "Workshop" : "Local";
        std::istringstream in(text);
        std::string line, v;
        bool gotName = false;
        while (std::getline(in, line)) {
            if (!line.empty() && line.back() == '\r') line.pop_back();
            if (!gotName && keyLine(line, "name", v)) { mi.name = v; gotName = true; }
            else if (mi.version.empty() && keyLine(line, "version", v)) mi.version = v;
            else if (mi.supported.empty() && keyLine(line, "supported_version", v)) mi.supported = v;
        }
        if (mi.name.empty()) mi.name = mi.id;
        out.push_back(std::move(mi));
    }
    std::sort(out.begin(), out.end(), [](const ModInfo& a, const ModInfo& b) { return lower(a.name) < lower(b.name); });
    return out;
}

inline std::vector<std::string> readDlcLoad(const std::string& dir) {
    std::vector<std::string> ids;
    if (dir.empty()) return ids;
    std::string text; J root;
    if (!readFile(P(dir) / "dlc_load.json", text) || !parseJson(text, root) || root.t != J::Obj) return ids;
    J* em = root.get("enabled_mods");
    if (!em || em->t != J::Arr) return ids;
    for (auto& v : em->a) {
        if (v.t != J::Str) continue;
        std::string s = v.s;
        std::replace(s.begin(), s.end(), '\\', '/');
        if (s.rfind("mod/", 0) == 0) s = s.substr(4);
        ids.push_back(s);
    }
    return ids;
}

// Make sure every installed mod appears in every playset and the active playset exists.
inline void syncStore(Store& st, const std::vector<ModInfo>& mods, const std::string& dir) {
    if (st.playsets.empty()) {
        Playset ps; ps.name = "Default";
        auto cur = readDlcLoad(dir);
        if (!cur.empty()) {
            ps.name = "Imported";
            for (auto& id : cur) ps.mods.push_back({id, true, ""});
        }
        st.playsets.push_back(std::move(ps));
    }
    std::map<std::string, std::string> names;
    for (auto& m : mods) names[m.id] = m.name;
    for (auto& ps : st.playsets) {
        std::set<std::string> have;
        for (auto& m : ps.mods) {
            have.insert(m.id);
            if (auto it = names.find(m.id); it != names.end()) m.name = it->second;
        }
        for (auto& m : mods) if (!have.count(m.id)) ps.mods.push_back({m.id, false, m.name});
    }
    if (!findPlayset(st, st.active)) st.active = st.playsets[0].name;
}

inline bool validID(const std::string& id) {
    if (id.size() < 5 || lower(id.substr(id.size() - 4)) != ".mod") return false;
    return id.find('/') == std::string::npos && id.find('\\') == std::string::npos && id.find("..") == std::string::npos;
}

struct ApplyResult { bool ok = false; std::string message; };

// Writes the playset to <dir>/dlc_load.json, keeping other keys, after saving a timestamped backup.
// Mods not present in `installed` are skipped.
inline ApplyResult applyPlayset(const std::string& dir, const Playset& ps, const std::set<std::string>& installed) {
    ApplyResult r;
    if (dir.empty()) { r.message = "CK3 folder is not set."; return r; }
    fs::path path = P(dir) / "dlc_load.json";
    J doc = J::obj();
    std::string old;
    if (readFile(path, old)) {
        J parsed;
        if (parseJson(old, parsed) && parsed.t == J::Obj) doc = std::move(parsed);
        char ts[32]; std::time_t t = std::time(nullptr);
        std::strftime(ts, sizeof ts, "%Y%m%d-%H%M%S", std::localtime(&t));
        fs::path bk = path; bk += std::string(".rc-backup-") + ts;
        if (!writeFile(bk, old)) { r.message = "Could not write a backup, so nothing was changed."; return r; }
    }
    if (!doc.get("disabled_dlcs")) doc.set("disabled_dlcs", J::arr());
    J list = J::arr();
    int n = 0, skipped = 0;
    for (auto& m : ps.mods) {
        if (!m.enabled || !validID(m.id)) continue;
        if (!installed.count(m.id)) { skipped++; continue; }
        list.a.push_back(J::str("mod/" + m.id)); n++;
    }
    doc.set("enabled_mods", std::move(list));
    std::string out; dump(doc, out);
    if (!writeFile(path, out)) { r.message = "Could not write dlc_load.json (is the game or launcher locking it?)."; return r; }
    r.ok = true;
    r.message = "Applied \"" + ps.name + "\": " + std::to_string(n) + " mods written to dlc_load.json (backup saved alongside)";
    if (skipped) r.message += "; " + std::to_string(skipped) + " enabled mod(s) skipped because they are not installed";
    r.message += ".";
    return r;
}

// ---------- playset import / export ----------
inline const char* PLAYSET_FORMAT = "royal-court-playset";

inline std::string sanitizeFileName(std::string n) {
    for (auto& c : n) if (std::string("\\/:*?\"<>|").find(c) != std::string::npos || (unsigned char)c < 0x20) c = '_';
    while (!n.empty() && (n.back() == ' ' || n.back() == '.')) n.pop_back();
    if (n.empty()) n = "playset";
    if (n.size() > 80) n.resize(80);
    return n;
}

inline std::string uniqueName(const Store& st, const std::string& base) {
    auto taken = [&](const std::string& n) { for (auto& p : st.playsets) if (p.name == n) return true; return false; };
    std::string b = base.empty() ? "Imported playset" : base;
    if (!taken(b)) return b;
    for (int i = 2; i < 10000; i++) {
        std::string c = b + " (" + std::to_string(i) + ")";
        if (!taken(c)) return c;
    }
    return b + " (new)";
}

// Exports the enabled mods of a playset, in load order, as a small shareable JSON file.
inline std::string exportPlayset(const Playset& ps, const std::map<std::string, ModInfo>& info) {
    J root = J::obj();
    root.set("format", J::str(PLAYSET_FORMAT));
    root.set("formatVersion", J::num(1));
    root.set("exportedBy", J::str(std::string("The Royal Court ") + VERSION));
    root.set("name", J::str(ps.name));
    J ms = J::arr();
    for (auto& m : ps.mods) {
        if (!m.enabled) continue;
        J mo = J::obj();
        mo.set("id", J::str(m.id));
        auto it = info.find(m.id);
        std::string nm = it != info.end() ? it->second.name : m.name;
        if (!nm.empty()) mo.set("name", J::str(nm));
        ms.a.push_back(std::move(mo));
    }
    root.set("mods", std::move(ms));
    std::string out; dump(root, out); out += "\n";
    return out;
}

struct ImportResult { bool ok = false; std::string error; Playset playset; int invalid = 0; };

inline ImportResult parsePlaysetFile(const std::string& text) {
    ImportResult r;
    if (text.size() > (5u << 20)) { r.error = "That file is too large to be a playset."; return r; }
    J root;
    if (!parseJson(text, root) || root.t != J::Obj) { r.error = "That file is not valid JSON."; return r; }
    J* f = root.get("format");
    if (!f || f->t != J::Str || f->s != PLAYSET_FORMAT) { r.error = "That file is not a Royal Court playset."; return r; }
    J* ms = root.get("mods");
    if (!ms || ms->t != J::Arr) { r.error = "The playset file has no mod list."; return r; }
    if (ms->a.size() > 5000) { r.error = "The playset file lists too many mods."; return r; }
    if (J* n = root.get("name"); n && n->t == J::Str) r.playset.name = n->s.substr(0, 100);
    std::set<std::string> seen;
    for (auto& mo : ms->a) {
        if (mo.t != J::Obj) { r.invalid++; continue; }
        J* i = mo.get("id");
        if (!i || i->t != J::Str || !validID(i->s)) { r.invalid++; continue; }
        if (!seen.insert(i->s).second) continue;
        ModRef m; m.id = i->s; m.enabled = true;
        if (J* nm = mo.get("name"); nm && nm->t == J::Str) m.name = nm->s;
        r.playset.mods.push_back(std::move(m));
    }
    r.ok = true;
    return r;
}

}  // namespace rc
